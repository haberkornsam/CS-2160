/* hex_plus.h */


unsigned int hex_plus_unsigned(char *num1, char *num2, int digit_num);
